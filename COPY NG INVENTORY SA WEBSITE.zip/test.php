<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "<h1>PHP is working!</h1>";

$host = 'sql211.infinityfree.com';
$user = 'if0_41783119';
$pass = 'ELTjbfFYuL'; // Siguraduhin na ito yung Hosting Password
$db   = 'if0_41783119_foodhub_db';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    echo "Successfully connected to the database!";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>