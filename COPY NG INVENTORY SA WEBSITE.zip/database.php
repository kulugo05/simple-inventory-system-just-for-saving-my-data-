<?php
$host = "sql211.infinityfree.com";
$dbname = "if0_41783119_foodhub_db";
$username = "if0_41783119";
$password = "ELTjbfFYuL";

function apiHeaders() {
    header("Content-Type: application/json");
    header("Access-Control-Allow-Origin: *");
}

function getDB() {
    global $host, $dbname, $username, $password;
    try {
        $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $db;
    } catch (PDOException $e) {
        header("Content-Type: application/json");
        echo json_encode(["error" => "Connection failed: " . $e->getMessage()]);
        exit;
    }
}

function jsonResponse($data, $status = 200) {
    header("Content-Type: application/json");
    http_response_code($status);
    echo json_encode($data);
    exit;
}
function getBody() {
    return json_decode(file_get_contents('php://input'), true) ?? [];
}