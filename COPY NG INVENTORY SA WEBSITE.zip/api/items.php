<?php
// ============================================================
// ITEMS API - api/items.php
// FIXED: Manila Time (+8 Hours) adjustment for Inventory Table
// ============================================================

require_once __DIR__ . '/../database.php';
apiHeaders();

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $id     = $_GET['id'] ?? null;
    $search = $_GET['search'] ?? '';
    $cat    = $_GET['category'] ?? 'all';
    $date   = $_GET['date'] ?? '';

    // DITO ANG FIX: Inadjust natin ang 'created_at' column para mag-plus 8 hours
    // para ang lilitaw sa table mo ay April 29, hindi April 28.
	$query  = "SELECT *, 
            DATE_ADD(created_at, INTERVAL 8 HOUR) as created_at, 
            CASE
                WHEN quantity <= 0 THEN 'out_of_stock'
                WHEN quantity <= reorder_level THEN 'low_stock'
                ELSE 'in_stock'
            END AS status FROM products WHERE 1=1";
    $params = [];

    if ($id) {
        $query .= " AND id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$id]);
        jsonResponse(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
    }

    if ($search) {
        $query   .= " AND (sku LIKE ? OR name LIKE ?)";
        $params[] = $search . '%';
        $params[] = '%' . $search . '%';
    }

    // Filter by Date (Inadjust din para mag-match sa +8 hours)
    if (!empty($date)) {
        $query   .= " AND DATE(DATE_ADD(created_at, INTERVAL 8 HOUR)) = ?";
        $params[] = $date;
    }

    if ($cat !== 'all') {
        $query   .= " AND category = ?";
        $params[] = $cat;
    }

    $query .= " ORDER BY id DESC";

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    jsonResponse(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
}

// ── SAVE / UPDATE (POST/PUT) ───────────────────────────
if ($method === 'POST' || $method === 'PUT') {
    $body = getBody();
    $id   = $_GET['id'] ?? null;

    $data = [
        $body['name'], $body['sku'], $body['category'],
        $body['unit'], $body['quantity'], $body['reorder_lvl'],
        $body['cost_price'], $body['sell_price'], $body['supplier'],
        $body['description']
    ];

    if ($id) {
        $sql = "UPDATE products SET name=?, sku=?, category=?, unit=?, quantity=?,
                reorder_level=?, cost_price=?, sell_price=?, supplier=?, description=?
                WHERE id=?";
        $data[] = $id;
    } else {
        // Kapag nag-insert, automatic na gagamit ng UTC ang NOW(), 
        // pero yung GET query sa itaas ang bahala mag-plus 8 pag-display.
        $sql = "INSERT INTO products (name, sku, category, unit, quantity, reorder_level,
                cost_price, sell_price, supplier, description) VALUES (?,?,?,?,?,?,?,?,?,?)";
    }

    $db->prepare($sql)->execute($data);

    if (!$id) {
        $newId = $db->lastInsertId();
        // Log setup with +8 hours
        $db->prepare("
            INSERT INTO stock_logs (item_id, item_name, type, amount, reason, timestamp)
            VALUES (?, ?, 'add', ?, 'New item added', DATE_ADD(NOW(), INTERVAL 8 HOUR))
        ")->execute([$newId, $body['name'], $body['quantity']]);
    }

    jsonResponse(['success' => true]);
}

// ── DELETE ────────────────────────────────────────
if ($method === 'DELETE') {
    $id = $_GET['id'] ?? null;
    $stmt = $db->prepare("SELECT name, quantity FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($product) {
        $db->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
        $db->prepare("
            INSERT INTO stock_logs (item_id, item_name, type, amount, reason, timestamp)
            VALUES (?, ?, 'remove', ?, 'Item deleted', DATE_ADD(NOW(), INTERVAL 8 HOUR))
        ")->execute([$id, $product['name'], $product['quantity']]);
    }
    jsonResponse(['success' => true]);
}