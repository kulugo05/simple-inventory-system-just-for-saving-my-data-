<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

// 1. Connection and Helper Functions
require_once __DIR__ . '/../database.php'; 
$db = getDB();

// Tawagin ang headers para sa JSON response
if (function_exists('apiHeaders')) {
    apiHeaders();
}

$method = $_SERVER['REQUEST_METHOD'];
$body   = getBody(); // Siguraduhing nasa database.php ito

// --- 2. GET: Kunin lahat ng users ---
if ($method === 'GET') {
    try {
        $users = $db->query("
            SELECT id, username, full_name, role, is_active, last_login, created_at
            FROM users
            ORDER BY created_at DESC
        ")->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse(['success' => true, 'data' => $users]);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => 'Database Error: ' . $e->getMessage()], 500);
    }
}

// --- 3. POST: Gumawa ng bagong account ---
if ($method === 'POST') {
    if (empty($body['username']) || empty($body['password']) || empty($body['fullname'])) {
        jsonResponse(['success' => false, 'message' => 'Punan ang lahat!'], 422);
    }

    // I-check kung existing na ang username
    $check = $db->prepare("SELECT id FROM users WHERE username = ?");
    $check->execute([trim($body['username'])]);
    if ($check->fetch()) {
        jsonResponse(['success' => false, 'message' => 'Username already exists!'], 409);
    }

    $hash = password_hash($body['password'], PASSWORD_DEFAULT);
    try {
        $db->prepare("INSERT INTO users (username, password, full_name, role) VALUES (?,?,?,?)")
           ->execute([trim($body['username']), $hash, trim($body['fullname']), $body['role'] ?? 'staff']);

        jsonResponse(['success' => true, 'message' => 'Account created!']);
    } catch (Exception $e) {
        jsonResponse(['success' => false, 'message' => $e->getMessage()], 500);
    }
}

// --- 4. PUT: I-reset ang password ---
if ($method === 'PUT') {
    if (empty($body['id']) || empty($body['password'])) {
        jsonResponse(['success' => false, 'message' => 'Missing data'], 422);
    }
    $hash = password_hash($body['password'], PASSWORD_DEFAULT);
    $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, (int)$body['id']]);
    jsonResponse(['success' => true, 'message' => 'Password reset!']);
}

// --- 5. PATCH: I-toggle status (Active/Inactive) ---
if ($method === 'PATCH') {
    if (!isset($body['id']) || !isset($body['is_active'])) {
        jsonResponse(['success' => false, 'message' => 'Missing data'], 422);
    }
    $db->prepare("UPDATE users SET is_active = ? WHERE id = ?")->execute([(int)$body['is_active'], (int)$body['id']]);
    jsonResponse(['success' => true, 'message' => 'User updated!']);
}